//variáveis da bolinha 
let xBolinha = 300;
let yBolinha = 200;
let diametro = 13;
//velocidade da bolinha 
let velocidadexBolinha = 6;
let velocidadeYBolinha = 6;
let raqueteComprimento = 10;
//variáveis da raquete
let xraquete = 5;
let yraquete = 150;
// variáveis do oponente 
let xRaqueteOponente = 585;
let yRaqueteOponente = 15;
let velocidadeYoponente;
let colidiu=false; 
//placar do jogo
let meuspontos = 0;
let pontosDoOponente = 0;




